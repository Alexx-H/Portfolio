package com.cs360.finalprojectalexhitchens;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.VH> {

    //  interface so the Activity can react when you tap a user
    public interface OnUserClick {
        void onUserClick(User user);
    }

    private final List<User> users;       // all the users we’re showing
    private final OnUserClick listener;   // who to call when one gets clicked

    // adapter gets handed the user list and the click handler
    public UserAdapter(List<User> users, OnUserClick listener) {
        this.users = users;
        this.listener = listener;
    }

    // when RecyclerView needs a new "bubble", inflate it from XML
    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user_bubble, parent, false);
        return new VH(v);
    }

    // fill the bubble with this user’s data (name + avatar)
    // name is important since we only have 4 avatars right now!
    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        User u = users.get(position);

        // show their username under the avatar
        h.tvUsername.setText(u.username);

        // load their avatar graphic based on the id
        h.btnAvatar.setImageResource(avatarResFor(h.itemView, u.avatarId));

        // if you tap the avatar, tell whoever’s listening (MainActivity)
        h.btnAvatar.setOnClickListener(v -> listener.onUserClick(u));
    }

    // Just says how many user bubbles to draw
    @Override
    public int getItemCount() { return users.size(); }

    // ViewHolder to store of the views inside each "bubble" row
    static class VH extends RecyclerView.ViewHolder {
        ImageButton btnAvatar;
        TextView tvUsername;
        VH(@NonNull View itemView) {
            super(itemView);
            btnAvatar = itemView.findViewById(R.id.btnAvatar);
            tvUsername = itemView.findViewById(R.id.tvUsername);
        }
    }

    //  pick which avatar image to use based on the string id
    private int avatarResFor(View v, String avatarId) {
        if (avatarId == null) return R.drawable.avatar1; // default fallback
        switch (avatarId) {
            case "2": return R.drawable.avatar2;
            case "3": return R.drawable.avatar3;
            case "4": return R.drawable.avatar4;
            default:  return R.drawable.avatar1;
        }
    }
}
