package com.cs360.finalprojectalexhitchens;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeightEntryDialogFragment extends DialogFragment {

    // this is the call back so the main activity can be notified
    public interface OnWeightAdded {
        void onWeightAdded(double weight);
    }

    // calling the new instance of the dialogue fragment
    public static AddWeightEntryDialogFragment newInstance() {
        return new AddWeightEntryDialogFragment();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        // Inflates the custom dialogue layout into view
        View v = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialogue_add_weight_entry, null, false);

        // grabbing the references from the layout
        EditText et = v.findViewById(R.id.editTextWeight);       // user input for weight
        TextView dateTv = v.findViewById(R.id.currentDateText);  // shows today’s date
        Button btnCancel = v.findViewById(R.id.buttonCancel);    // cancel button
        Button btnSave = v.findViewById(R.id.buttonSave);        // save/ok button

        // get the current date
        dateTv.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(new Date()));

        // Create a plain Dialog box and set it to the custom view
        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(v);

        // create a listener for the cancel button and close box (cancels)
        btnCancel.setOnClickListener(view -> dialog.dismiss());

        // Create listener for the save button
        btnSave.setOnClickListener(view -> {

            //get the string from the entered text and make sure it's ok
            //using the check if it's null of
            String s = et.getText() == null ? "" : et.getText().toString().trim();

            // This will Validate that something was entered
            if (s.isEmpty()) {
                et.setError(getString(R.string.enter_weight));  // shows an error if empty
                return;
            }
            try {
                // Parses the string to a double
                double w = Double.parseDouble(s);

                // Check if the originating Activity has a call back interface
                if (getActivity() instanceof OnWeightAdded) {
                    // If it does (cause I made it) go send back the weight
                    ((OnWeightAdded) getActivity()).onWeightAdded(w);
                }

                // close the dialogue box
                dialog.dismiss();
            } catch (NumberFormatException ex) {
                // if the parsing fails (like there are letters or something) give error.
                et.setError(getString(R.string.enter_weight));
            }
        });

        // Return the configured dialog to be shown
        return dialog;
    }
}
