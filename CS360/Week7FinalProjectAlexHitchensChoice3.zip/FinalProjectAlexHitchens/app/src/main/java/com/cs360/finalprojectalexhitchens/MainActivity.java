package com.cs360.finalprojectalexhitchens;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class MainActivity extends AppCompatActivity {

    // RecyclerView rv to show the list of users
    private RecyclerView rv;
    // Database helper to access SQLite
    private SSWLUserDatabase dbHelper;

    // request code number for the sms permission
    private static final int REQ_SEND_SMS = 1;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set up the database helper
        dbHelper = new SSWLUserDatabase(this);

        // Setup the recycle view for user list by ID
        rv = findViewById(R.id.rvUsers);
        // Changes how the rv is going to look, I wanted horizontal like netflix style
        rv.setLayoutManager(
                new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)); // horizontal list
        new LinearSnapHelper().attachToRecyclerView(rv);

        // Load users the load user function below
        List<User> users = loadUsers();
        // this is the pass call back from when it is clicked using the adapter
        rv.setAdapter(new UserAdapter(users, this::onUserClicked));

        // this starts a listener on the bottom button and starts up the new user activity
        // when it is clicked
        findViewById(R.id.btnNewUser).setOnClickListener(v -> {
            startActivity(new Intent(this, NewUserActivity.class));
        });

        // Show the sms dialogue at launch
        showSmsApprovalDialogue();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the user list when returning
        List<User> users = loadUsers();
        rv.setAdapter(new UserAdapter(users, this::onUserClicked));
    }

    // Load all user records from the database and put them into a user object list
    private List<User> loadUsers() {
        // create a new list of users called... wait for it... list!
        List<User> list = new ArrayList<>();
        // load up the old dbHelper named db
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query the database to get the ordered list of users by user name
        // and store in a cursor c
        Cursor c = db.query(
                SSWLUserDatabase.SSWLUserTable.TABLE,
                null, // select all columns
                null, null, null, null,
                SSWLUserDatabase.SSWLUserTable.COL_USERNAME + " COLLATE NOCASE ASC"
        );

        // get the column index for each item so we don't have to keep getting it
        int idIdx = c.getColumnIndex(SSWLUserDatabase.SSWLUserTable.COL_ID);
        int uIdx  = c.getColumnIndex(SSWLUserDatabase.SSWLUserTable.COL_USERNAME);
        int pIdx  = c.getColumnIndex(SSWLUserDatabase.SSWLUserTable.COL_PIN);
        int aIdx  = c.getColumnIndex(SSWLUserDatabase.SSWLUserTable.COL_AVATARID);
        int gIdx  = c.getColumnIndex(SSWLUserDatabase.SSWLUserTable.COL_GOAL_WEIGHT);

        // Loop through rows using the above column indexes, build User object
        while (c.moveToNext()) {
            long id = c.getLong(idIdx);
            String username = c.getString(uIdx);
            String pin = c.getString(pIdx);
            String avatarId = c.getString(aIdx);
            double goal = c.getDouble(gIdx);

            // add them to the list!
            list.add(new User(id, username, pin, avatarId, goal));
        }
        // close out your pointers!
        c.close();
        // return the list
        return list;
    }

    // Show and run the custome sms message
    private void showSmsApprovalDialogue() {
        // inflate on the screen
        View dialogView = getLayoutInflater().inflate(R.layout.dialogue_sms_warning, null);

        // I made this alert non cancelable so they have to choose!
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        // grab the layout buttons
        Button btnYes = dialogView.findViewById(R.id.button);
        Button btnNo  = dialogView.findViewById(R.id.button2);

        // If Yes, dimiss the box and request the permission
        // which opens another box that i guess is required by android?
        btnYes.setOnClickListener(v -> {
            dialog.dismiss();
            requestSmsPermission();
        });

        // If no, dismiss the box and toast their choice to let them know!
        btnNo.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(this, "SMS notifications... disabled!", Toast.LENGTH_SHORT).show();
        });

        // Show the dialog
        dialog.show();

        // the dialogue window layout, weapping the content!
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    // ca.lled when the user gets tapped in the RV... this took so long!
    private void onUserClicked(User user) {
        // Create an EditText for entering PIN coming up
        final EditText input = new EditText(this);
        // make the input be a number... a secret number
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);

        // this is the alert dialogue for the pin
        new AlertDialog.Builder(this)
                // set title is the aprt at the top
                .setTitle("Enter PIN for " + user.username)
                // the input
                .setView(input)
                // positive button is the ok
                .setPositiveButton("Let's get Fit!", (d, which) -> {
                    // get the text and make sure  it is not null and set to "" if it is
                    String entered = input.getText() == null ? "" : input.getText().toString();

                    //if the entered number matches... toast welcome to the user!
                    if (entered.equals(user.pin)) {
                        Toast.makeText(this, "Welcome " + user.username + "!", Toast.LENGTH_SHORT).show();
                        // start up the main data page!
                        startActivity(new Intent(this, MainDatapageActivity.class)
                                .putExtra("user_id", user.id));

                    } else {
                        // you got the wrong pin toast
                        Toast.makeText(this, "Incorrect PIN!", Toast.LENGTH_SHORT).show();
                    }
                })
                // this is just the cancel button get out of here!
                .setNegativeButton("Never Mind", null)
                .show();
    }

    // this is to ask the system for SMS permissions
    private void requestSmsPermission() {
        // standard part
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // unless it's allready gotten show the system dialogue
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
        } else {
            // we allready have me permission
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
        }
    }

    // handle what happens because of the result
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // check to see if the requestcode matches the one we made up
        if (requestCode == REQ_SEND_SMS) {
            // if it does and it is greater then 0 and we have permission granted
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // toast to the user accepting
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();

            } else {
                // this means the user denied access
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
