package com.cs360.finalprojectalexhitchens;

// this is the class for the user class
public class User {
    public long id;
    public String username;
    public String pin;
    public String avatarId;
    public double goal_weight;

    public User(long id, String username, String pin, String avatarId, Double goal) {
        this.id = id;
        this.username = username;
        this.pin = pin;
        this.avatarId = avatarId;
        this.goal_weight = goal;
    }
}