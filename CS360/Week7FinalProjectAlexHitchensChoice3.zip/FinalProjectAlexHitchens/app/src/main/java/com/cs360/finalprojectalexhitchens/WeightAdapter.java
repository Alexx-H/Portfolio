package com.cs360.finalprojectalexhitchens;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    // Callback so the delete button works
    public interface OnDelete {
        void onDelete(WeightRow row);
    }

    // one weight entry displayed in the list
    public static class WeightRow {
        public final long id;       // id
        public final long ts;       // timestamp
        public final double weight; // weight
        public WeightRow(long id, long ts, double weight) {
            this.id = id; this.ts = ts; this.weight = weight;
        }
    }

    // the list for the adapter
    private final List<WeightRow> items;  // backing list for the adapter
    // call back when delete is pressed
    private final OnDelete onDelete;
    // the date format
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    // pass initial rowes then delete the callback
    public WeightAdapter(List<WeightRow> items, OnDelete onDelete) {
        this.items = items;
        this.onDelete = onDelete;
    }

    // Inflate a row view when the reciecle view needs one
    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new VH(v);
    }

    // Bind data to the holder
    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        WeightRow r = items.get(position);

        // show the time after it is formated
        h.tvDate.setText(fmt.format(new Date(r.ts)));

        // Show the numeric weight
        h.tvWeight.setText(String.valueOf(r.weight));

        // hook up the dlete button to a specific row
        h.btnDelete.setOnClickListener(v -> onDelete.onDelete(r));
    }

    // Required by RecyclerView
    @Override public int getItemCount() { return items.size(); }

    // Replace the entire list with new data and refresh the UI
    public void replaceAll(List<WeightRow> newItems) {
        items.clear();            // clear the old rows
        items.addAll(newItems);   // add fresh rows
        notifyDataSetChanged();   // tell RecyclerView everything may have changed
    }

    // ViewHolder holds data for ease of use.
    static class VH extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;   // date and weight text fields
        ImageButton btnDelete;       // delete button

        VH(@NonNull View itemView) {
            super(itemView);
            // Bind the child views
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
