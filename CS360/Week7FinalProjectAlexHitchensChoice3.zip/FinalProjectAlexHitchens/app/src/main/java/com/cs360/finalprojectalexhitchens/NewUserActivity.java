
package com.cs360.finalprojectalexhitchens;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NewUserActivity extends AppCompatActivity {

    // Variables for the entered information
    private EditText etUsername;
    private EditText etPin;
    private EditText etGoal;
    private RadioGroup rgAvatars;

    //making a data base helper
    private SSWLUserDatabase dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        etUsername = findViewById(R.id.editTextText); // Get the user name by its label
        etPin = findViewById(R.id.editTextNumberPassword3); // get the pin number by label
        rgAvatars = findViewById(R.id.radioGroup1); // get radio group by id label
        etGoal = findViewById(R.id.editTextText4); // get the goal weight by id label
        dbHelper = new SSWLUserDatabase(this); //make a new user database

        // find the save user button and listen for it's click and run function
        findViewById(R.id.btnCreateUser).setOnClickListener(v ->
                onCreateUserClicked()
        );

        // find the cancel button by id and then listen for it's click
        findViewById(R.id.btnCancel).setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }

    // This function creates the new user
    private void onCreateUserClicked() {

        //take the values entered, run them through the safeText() function to make sure
        //they arn't going to throw issues, then set to simple terms
        String username = safeText(etUsername);
        String pin = safeText(etPin);
        String avatarId = String.valueOf(getSelectedAvatarId());
        String goal = safeText(etGoal);

        //Check they entered a user name and pin and notify via toast
        if (username.isEmpty() || pin.isEmpty()) {
            Toast.makeText(this, "Username and PIN are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // insert the new user, and get the returned row id
        long rowId = insertUser(username, pin, avatarId, goal);

        // if the row id is -1 it means something went wrong, it returns this on problems,
        // so if it does let the user know
        if (rowId == -1) {
            Toast.makeText(this, "Insert failed (maybe username duplicate?).", Toast.LENGTH_SHORT).show();
            return;
        }

        // Simple fetch to show it worked
        String summary = fetchUserSummary(username);
        Toast.makeText(this, "Saved!\n" + summary, Toast.LENGTH_LONG).show();

        //data found so exit
        finish();
    }

    // this function puts a user into the database
    private long insertUser(String username, String pin, String avatarId, String goal) {
        // get a writable database helper db
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        //make a new content value object cv
        ContentValues cv = new ContentValues();

        // put the stored values of the user into cv
        cv.put(SSWLUserDatabase.SSWLUserTable.COL_USERNAME, username);
        cv.put(SSWLUserDatabase.SSWLUserTable.COL_PIN, pin);
        cv.put(SSWLUserDatabase.SSWLUserTable.COL_AVATARID, avatarId);
        cv.put(SSWLUserDatabase.SSWLUserTable.COL_GOAL_WEIGHT, goal);

        //inset the cv content values into the database and return whatever comes back
        return db.insert(SSWLUserDatabase.SSWLUserTable.TABLE, null, cv);
    }

    // this function gets the usr data from the database
    private String fetchUserSummary(String username) {
        // get a readable database and set to db
        SQLiteDatabase db = dbHelper.getReadableDatabase();


        String[] cols = {
                SSWLUserDatabase.SSWLUserTable.COL_USERNAME,
                SSWLUserDatabase.SSWLUserTable.COL_PIN,
                SSWLUserDatabase.SSWLUserTable.COL_AVATARID,
                SSWLUserDatabase.SSWLUserTable.COL_GOAL_WEIGHT
        };

        String selection = SSWLUserDatabase.SSWLUserTable.COL_USERNAME + " = ?";
        String[] args = { username };

        Cursor c = db.query(
                SSWLUserDatabase.SSWLUserTable.TABLE,
                cols,
                selection,
                args,
                null,
                null,
                null
        );

        String result = "No record found";
        if (c.moveToFirst()) {
            String u = c.getString(0);
            String p = c.getString(1);
            String a = c.getString(2);
            String g = c.getString(3);
            result = "user=" + u + ", pin=" + p + ", avatarId=" + a + ", goal=" + g;
        }
        c.close();
        return result;
    }

    private int getSelectedAvatarId() {
        // gets the id of the checked radio button in the group
        int checkedId = rgAvatars.getCheckedRadioButtonId();

        // if they didn't select any avatar give them the first one
        if (checkedId == View.NO_ID) {
            return 1; // default to first
        }

        //get the radio button that is checked in the group
        RadioButton rb = findViewById(checkedId);

        // get the return the number of the radio checked
        if (rb.getId() == R.id.radioButton1) return 1;
        if (rb.getId() == R.id.radioButton2) return 2;
        if (rb.getId() == R.id.radioButton3) return 3;
        if (rb.getId() == R.id.radioButton4) return 4;

        //default fall back return
        return 1;
    }

    //check to make sure the text isn't
    private static String safeText(EditText e) {
        CharSequence cs = e.getText();
        // return the character sequence as null if blank but otherwise return a trimmed string
        return cs == null ? "" : cs.toString().trim();
    }
}