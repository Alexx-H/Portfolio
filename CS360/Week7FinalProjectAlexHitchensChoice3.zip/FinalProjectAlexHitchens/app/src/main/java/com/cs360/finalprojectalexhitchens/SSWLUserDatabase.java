package com.cs360.finalprojectalexhitchens;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;


public class SSWLUserDatabase extends SQLiteOpenHelper {

    // setting database name
    private static final String DATABASE_NAME = "SSWLUser.db";
    // for making changes later if needed
    private static final int VERSION = 1;

    // This is the table of users
    public static final class SSWLUserTable {
        public static final String TABLE = "users";
        public static final String COL_ID = "_id";
        public static final String COL_USERNAME = "username";
        public static final String COL_PIN = "pin";
        public static final String COL_AVATARID = "avatarid";
        public static final String COL_GOAL_WEIGHT = "goalweight";
    }

    // This is the table for weights
    public static final class WeightTable {
        public static final String TABLE = "weights";
        public static final String COL_ID = "_id";
        public static final String COL_USER_ID = "user_id";
        public static final String COL_TS = "ts";
        public static final String COL_WEIGHT = "weight";
    }

    // standard func for creating the database
    public SSWLUserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // users table creation
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + SSWLUserTable.TABLE + " (" +
                        SSWLUserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        SSWLUserTable.COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        SSWLUserTable.COL_PIN + " TEXT, " +
                        SSWLUserTable.COL_AVATARID + " INTEGER NOT NULL, " +
                        SSWLUserTable.COL_GOAL_WEIGHT + " REAL" +                                        ")"
        );

        // weights table creation
        db.execSQL(
                "CREATE TABLE IF NOT EXISTS " + WeightTable.TABLE + " (" +
                        WeightTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        WeightTable.COL_USER_ID + " INTEGER NOT NULL, " +
                        WeightTable.COL_TS + " INTEGER NOT NULL, " +
                        WeightTable.COL_WEIGHT + " REAL NOT NULL" +

                        ")"
        );
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_weights_user_ts ON " +
                WeightTable.TABLE + " (" + WeightTable.COL_USER_ID + ", " + WeightTable.COL_TS + " DESC)");
    }

    // incase the version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + WeightTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + SSWLUserTable.TABLE);
        onCreate(db);
    }


     // inset the weight of a current entry.aka when we add a new weight
    public long insertWeightNow(long userId, double weight) {
        return insertWeight(userId, System.currentTimeMillis(), weight);
    }

   // insert weight at a spacific time utilized by insertWeightNow()
    public long insertWeight(long userId, long epochMillis, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(WeightTable.COL_USER_ID, userId);
        cv.put(WeightTable.COL_TS, epochMillis);
        cv.put(WeightTable.COL_WEIGHT, weight);
        return db.insert(WeightTable.TABLE, null, cv);
    }

    //latest weights for a specific user, given by userID
    public Cursor queryLatestWeights(long userId, int limit) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                WeightTable.TABLE,
                null,
                WeightTable.COL_USER_ID + "=?",
                new String[]{ String.valueOf(userId) },
                null, null,
                WeightTable.COL_TS + " DESC",
                String.valueOf(limit)
        );
    }

    // get the goal weight of a specific user, useful for the datapage
    public Double getGoalWeight(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(SSWLUserTable.TABLE,
                new String[]{ SSWLUserTable.COL_GOAL_WEIGHT },
                SSWLUserTable.COL_ID + "=?",
                new String[]{ String.valueOf(userId) }, null, null, null, "1")) {
            if (c.moveToFirst() && !c.isNull(0)) return c.getDouble(0);
        }
        return null;
    }

    // this function gets the most recent weight, again for the datapage
    public Double getLatestWeight(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(WeightTable.TABLE,
                new String[]{ WeightTable.COL_WEIGHT },
                WeightTable.COL_USER_ID + "=?",
                new String[]{ String.valueOf(userId) },
                null, null, WeightTable.COL_TS + " DESC", "1")) {
            if (c.moveToFirst()) return c.getDouble(0);
        }
        return null;
    }

    // this function deletes the weights from the table.
    public int deleteWeight(long weightId) {
        return getWritableDatabase().delete(
                WeightTable.TABLE, WeightTable.COL_ID + "=?", new String[]{ String.valueOf(weightId) }
        );
    }
}
