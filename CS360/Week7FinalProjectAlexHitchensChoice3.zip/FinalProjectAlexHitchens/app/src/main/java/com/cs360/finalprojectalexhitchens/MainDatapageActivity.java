package com.cs360.finalprojectalexhitchens;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;

public class MainDatapageActivity extends AppCompatActivity
        implements AddWeightEntryDialogFragment.OnWeightAdded {  // receive weight-added callback from dialog

    // which user we are talking about
    private long userId;
    // database helper
    private SSWLUserDatabase db;

    // the two labels we gonna use
    private TextView goalWeightText, latestWeightText;
    // the recycle view adapter
    private WeightAdapter adapter;

    // I believe this is part of what you need to save if you have allready sent and SMS
    // message or not but was having issues making it work right, and running out of time
    private static final String PREFS = "app_prefs";
    private static final String KEY_GOAL_SMS_PREFIX = "goal_sms_sent_user_";

    //standard stuff
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_datapage);

        // this gets the user id from what was passed from main activity
        userId = getIntent().getLongExtra("user_id", -1);

        // if for some reason there is no user ID GTFO
        if (userId < 0) {
            Toast.makeText(this, "How did you even get here?", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // initialize the db
        db = new SSWLUserDatabase(this); // init DB helper

        // set those labels to the texts
        goalWeightText = findViewById(R.id.goalWeightText);
        latestWeightText = findViewById(R.id.latestWeightText);

        // Setup the list of weight rv
        RecyclerView rv = findViewById(R.id.weightRecyclerView);
        //  make this list verticl unlike the otehr one
        rv.setLayoutManager(new LinearLayoutManager(this));
        //this is the call back for the delete
        adapter = new WeightAdapter(new ArrayList<>(), this::confirmDelete);

        rv.setAdapter(adapter);

        // this is for the FAB
        findViewById(R.id.addEntryButton).setOnClickListener(v -> {
            AddWeightEntryDialogFragment.newInstance()
                    .show(getSupportFragmentManager(), "addWeight");
        });

        // populate the header and the list
        refreshHeader();
        refreshList();
    }

    // Refresh the top labels showing goal and latest weight
    private void refreshHeader() {
        Double goal = db.getGoalWeight(userId);     // get that goal weight from the db based on id
        Double latest = db.getLatestWeight(userId); // get the latest from the db based on id
        // set the header text or put none i
        goalWeightText.setText(getString(R.string.goal) + " " + (goal == null ? "None!" : String.valueOf(goal)));
        latestWeightText.setText(getString(R.string.latest) + " " + (latest == null ? "None!" : String.valueOf(latest)));
    }

    // Query all the weights and send them to the adaptor
    private void refreshList() {
        List<WeightAdapter.WeightRow> rows = new ArrayList<>();
        // try to get the values of the database into a cursor named c
        try (Cursor c = db.queryLatestWeights(userId, Integer.MAX_VALUE)) {
            // get the indexs for each of the columns
            int idIdx = c.getColumnIndex(SSWLUserDatabase.WeightTable.COL_ID);
            int tsIdx = c.getColumnIndex(SSWLUserDatabase.WeightTable.COL_TS);
            int wIdx  = c.getColumnIndex(SSWLUserDatabase.WeightTable.COL_WEIGHT);
            // Build rows from the c columns
            while (c.moveToNext()) {
                rows.add(new WeightAdapter.WeightRow(
                        c.getLong(idIdx),
                        c.getLong(tsIdx),
                        c.getDouble(wIdx)
                ));
            }
        }
        // swap with the adaptors data
        adapter.replaceAll(rows);
    }

    // ask beore delete
    private void confirmDelete(WeightAdapter.WeightRow row) {
        new AlertDialog.Builder(this)
                // ask to delete
                .setMessage(getString(R.string.delete) + " " + row.weight + "?")
                // the positivve button deletes by row then refreshes
                .setPositiveButton(R.string.delete, (d, w) -> {
                    db.deleteWeight(row.id); // delete by row id
                    refreshHeader();         // header might change (if latest deleted)
                    refreshList();           // refresh list to remove the row
                })
                // negative button just cancels.
                .setNegativeButton(R.string.cancel, null) // do nothing on cancel
                .show();
    }

    // check the goal
    private void checkGoal(double goal, double currentWeight) {
        //reached or under goal
        if (currentWeight <= goal) {
            // did we allready send this?
            if (!hasSentGoalSms(userId)) {
                String msg = "Huzzah! You hit your goal weight (" + goal + "). You are a champ!!";

                // try to get the phonenumber of the phone
                String phone = getOwnPhoneNumberOrNull();

                //if the number was successful
                if (phone != null && !phone.isEmpty()) {
                    //send the text!
                    sendSms(phone, msg);
                    // mark that we sent the text
                    markGoalSmsSent(userId);
                    // couldn't get the number
                } else {
                    // toast the user that the number failed
                    Toast.makeText(this,
                            "Goal reached! Unable to send text!",
                            Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    // Callback from AddWeightEntryDialogFragment
    @Override
    public void onWeightAdded(double weight) {
        db.insertWeightNow(userId, weight);
        refreshHeader();
        refreshList();

        // If a goal exists, check
        Double goal = db.getGoalWeight(userId);
        if (goal != null) {
            checkGoal(goal, weight);        // compares new weight
        }
    }


// check if message has been sent
    private boolean hasSentGoalSms(long userId) {
        return getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_GOAL_SMS_PREFIX + userId, false); // default false
    }

    // this makes the goal as sent (when we do it.
    private void markGoalSmsSent(long userId) {
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_GOAL_SMS_PREFIX + userId, true)
                .apply();
    }

    // phone helpers, most of these i got offline, i learned it is actually kind of tricky
    //for an app to get it's own number

    @Nullable
    private String getOwnPhoneNumberOrNull() {
        // System service that exposes line info
        android.telephony.TelephonyManager tm =
                (android.telephony.TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (tm == null) return null;

        // we check both of these cause different devices use different ones
        boolean hasReadNum = androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.READ_PHONE_NUMBERS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED;

        boolean hasReadState = androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.READ_PHONE_STATE
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED;

        // if there is not a number or state return null
        if (!hasReadNum && !hasReadState) return null;

        try {
            // another attempt to get number
            String n = tm.getLine1Number();
            if (n != null && !n.trim().isEmpty()) return n;
        } catch (SecurityException ignored) { // we tried!
             }
        return null;
    }
    // this actually sends the message
    private void sendSms(String phone, String message) {
        // skips if no permission
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.SEND_SMS
        ) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            // send message to phone numer if got or...
            android.telephony.SmsManager sms = android.telephony.SmsManager.getDefault();
            sms.sendTextMessage(phone, null, message, null, null);
            android.widget.Toast.makeText(this,
                    "Congrats SMS sent to " + phone,
                    android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // sends message that it did go through
            android.widget.Toast.makeText(this,
                    "Failed to send SMS: " + e.getMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }
}
